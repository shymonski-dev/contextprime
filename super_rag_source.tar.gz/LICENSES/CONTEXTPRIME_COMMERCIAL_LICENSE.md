# Contextprime Commercial License

Copyright (c) 2026 Contextprime Contributors.

## Commercial use path

This repository is offered under dual licensing.

Commercial, closed source, or proprietary use is available under a separate
commercial license agreement with the copyright holders.

No commercial license rights are granted by this file alone. Commercial rights
are granted only through a signed commercial license agreement.

## How to request a commercial license

Open a repository issue titled `Commercial License Inquiry` or contact the
repository owner through GitHub to request commercial terms.

## Default license when no commercial agreement exists

If no signed commercial agreement exists, use of this software is governed by
the GNU Affero General Public License, version 3 or any later version.
