# Dual License Notice

Contextprime is available under a dual license model:

1. GNU Affero General Public License, version 3 or any later version
2. Contextprime Commercial License (separate signed agreement)

If you do not have a signed commercial license agreement, your use is governed
by the GNU Affero General Public License.

License files:

- `LICENSE`
- `LICENSES/CONTEXTPRIME_COMMERCIAL_LICENSE.md`
