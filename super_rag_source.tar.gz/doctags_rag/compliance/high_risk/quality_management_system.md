# High Risk Quality Management System

Status: Template. Complete this file before any high risk deployment.

Required sections:

1. Roles and responsibilities.
2. Design control and change control.
3. Supplier and dependency management.
4. Corrective and preventive action process.
5. Management review cadence.
