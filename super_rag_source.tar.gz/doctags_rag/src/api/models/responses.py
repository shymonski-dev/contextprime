"""
Response models for API endpoints.

Defines Pydantic models for API responses.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class ProcessingStatus(str, Enum):
    """Document processing status."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class DocumentInfo(BaseModel):
    """Information about a processed document."""
    id: str = Field(..., description="Document ID")
    filename: str = Field(..., description="Original filename")
    file_type: str = Field(..., description="File type/extension")
    file_size_bytes: int = Field(..., description="File size in bytes")
    num_chunks: int = Field(..., description="Number of chunks created")
    num_entities: Optional[int] = Field(None, description="Number of entities extracted")
    processing_time: float = Field(..., description="Processing time in seconds")
    status: ProcessingStatus = Field(..., description="Processing status")
    uploaded_at: datetime = Field(..., description="Upload timestamp")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class UploadResponse(BaseModel):
    """Response for document upload."""
    success: bool = Field(..., description="Whether upload succeeded")
    document: Optional[DocumentInfo] = Field(None, description="Processed document info")
    message: str = Field(..., description="Status message")
    processing_time: float = Field(..., description="Total processing time in seconds")


class SearchResultItem(BaseModel):
    """Single search result item."""
    id: str = Field(..., description="Result ID")
    content: str = Field(..., description="Text content")
    score: float = Field(..., description="Relevance score")
    confidence: float = Field(..., description="Confidence score")
    source: str = Field(..., description="Source (vector/graph/hybrid)")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Result metadata")
    graph_context: Optional[Dict[str, Any]] = Field(None, description="Knowledge graph context")


class QueryResponse(BaseModel):
    """Response for query requests."""
    success: bool = Field(..., description="Whether query succeeded")
    query: str = Field(..., description="Original query text")
    results: List[SearchResultItem] = Field(default_factory=list, description="Search results")
    total_results: int = Field(..., description="Total number of results")
    processing_time: float = Field(..., description="Query processing time in seconds")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional query metadata")


class ChunkSummary(BaseModel):
    """Summary of a processed chunk."""
    chunk_id: str = Field(..., description="Unique chunk identifier")
    content: str = Field(..., description="Chunk content")
    length: int = Field(..., description="Content length in characters")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Chunk metadata")
    context: Dict[str, Any] = Field(default_factory=dict, description="Chunk context breadcrumbs")


class DocumentDetailResponse(BaseModel):
    """Detailed information about a processed document."""
    success: bool = Field(..., description="Whether retrieval succeeded")
    document: DocumentInfo = Field(..., description="High-level document information")
    chunks: List[ChunkSummary] = Field(default_factory=list, description="Processed chunks")
    markdown: Optional[str] = Field(None, description="Document content rendered as Markdown")
    text_preview: Optional[str] = Field(None, description="Excerpt of the original text")
    doctags: Optional[Dict[str, Any]] = Field(None, description="DocTags structure for the document")
    message: Optional[str] = Field(None, description="Additional status message")


class ServiceStatus(str, Enum):
    """Service health status."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class ServiceInfo(BaseModel):
    """Information about a service."""
    name: str = Field(..., description="Service name")
    status: ServiceStatus = Field(..., description="Service status")
    message: Optional[str] = Field(None, description="Status message")
    response_time_ms: Optional[float] = Field(None, description="Response time in milliseconds")
    details: Dict[str, Any] = Field(default_factory=dict, description="Additional details")


class SystemStatus(BaseModel):
    """Overall system status."""
    status: ServiceStatus = Field(..., description="Overall system status")
    timestamp: datetime = Field(..., description="Status check timestamp")
    uptime_seconds: float = Field(..., description="System uptime in seconds")
    services: Dict[str, ServiceInfo] = Field(default_factory=dict, description="Individual service statuses")


class SystemStats(BaseModel):
    """System statistics."""
    total_documents: int = Field(..., description="Total documents processed")
    total_chunks: int = Field(..., description="Total chunks created")
    total_entities: int = Field(..., description="Total entities extracted")
    total_queries: int = Field(..., description="Total queries processed")
    avg_query_time_ms: float = Field(..., description="Average query time in milliseconds")
    cache_hit_rate: float = Field(..., description="Cache hit rate (0-1)")
    storage_used_mb: float = Field(..., description="Storage used in megabytes")
    last_updated: datetime = Field(..., description="Last update timestamp")


class DocumentListResponse(BaseModel):
    """Response for listing documents."""
    success: bool = Field(..., description="Whether request succeeded")
    documents: List[DocumentInfo] = Field(default_factory=list, description="List of documents")
    total: int = Field(..., description="Total number of documents")
    page: int = Field(default=1, description="Current page number")
    page_size: int = Field(default=50, description="Page size")


class DeleteResponse(BaseModel):
    """Response for delete operations."""
    success: bool = Field(..., description="Whether deletion succeeded")
    message: str = Field(..., description="Status message")
    deleted_id: Optional[str] = Field(None, description="ID of deleted document")


class ErrorResponse(BaseModel):
    """Error response model."""
    success: bool = Field(default=False, description="Always false for errors")
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")


class HealthResponse(BaseModel):
    """Health check response with dependency readiness context."""
    status: str = Field(..., description="Health status")
    timestamp: datetime = Field(..., description="Check timestamp")
    version: str = Field(default="1.0.0", description="API version")
    ready: Optional[bool] = Field(default=None, description="Whether required services are ready")
    services: Dict[str, bool] = Field(default_factory=dict, description="Dependency health map")
    missing_services: List[str] = Field(default_factory=list, description="Unhealthy required services")


class AgenticQueryResponse(BaseModel):
    """Response for agentic RAG queries."""
    success: bool = Field(..., description="Whether query succeeded")
    query: str = Field(..., description="Original query")
    answer: str = Field(..., description="Final answer")
    confidence: float = Field(..., description="Answer confidence score")
    iterations: int = Field(..., description="Number of iterations performed")
    reasoning_steps: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Reasoning steps (if requested)"
    )
    sources: List[SearchResultItem] = Field(
        default_factory=list,
        description="Source documents used"
    )
    processing_time: float = Field(..., description="Total processing time in seconds")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class RetrievalFeedbackResponse(BaseModel):
    """Response for retrieval feedback submissions."""

    success: bool = Field(..., description="Whether feedback submission succeeded")
    query_id: str = Field(..., description="Query identifier feedback was attached to")
    feedback_id: str = Field(..., description="Stored feedback event identifier")
    message: str = Field(..., description="Status message")


class Neo4jConnectivityResponse(BaseModel):
    """Response for Neo4j connectivity checks."""

    connected: bool = Field(..., description="Whether configured credentials can connect")
    configured_password_present: bool = Field(
        ...,
        description="Whether Neo4j password is configured in runtime settings",
    )
    message: str = Field(..., description="Human readable status message")


class Neo4jPasswordRecoveryResponse(BaseModel):
    """Response for Neo4j password verification and save."""

    success: bool = Field(..., description="Whether the submitted password is valid")
    persisted: bool = Field(..., description="Whether password was written to local .env file")
    message: str = Field(..., description="Human readable result message")
