"""
Request models for API endpoints.

Defines Pydantic models for validating incoming API requests.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, field_validator
from enum import Enum
import re


class ChunkingMethod(str, Enum):
    """Chunking method options."""
    STRUCTURE = "structure"
    SEMANTIC = "semantic"


class DocumentUploadRequest(BaseModel):
    """Request model for document upload."""
    enable_ocr: bool = Field(
        default=True,
        description="Enable OCR processing for images and scanned PDFs"
    )
    chunk_size: int = Field(
        default=1000,
        ge=100,
        le=5000,
        description="Size of text chunks in characters"
    )
    chunk_overlap: int = Field(
        default=200,
        ge=0,
        le=1000,
        description="Overlap between chunks in characters"
    )
    chunking_method: ChunkingMethod = Field(
        default=ChunkingMethod.STRUCTURE,
        description="Method to use for chunking"
    )
    extract_entities: bool = Field(
        default=True,
        description="Extract entities and build knowledge graph"
    )
    build_raptor: bool = Field(
        default=False,
        description="Build RAPTOR hierarchical summary tree"
    )

    @field_validator('chunk_overlap')
    @classmethod
    def validate_overlap(cls, v: int, info) -> int:
        """Validate that overlap is less than chunk size."""
        chunk_size = info.data.get('chunk_size', 1000)
        if v >= chunk_size:
            raise ValueError("chunk_overlap must be less than chunk_size")
        return v


class QueryRequest(BaseModel):
    """Simple query request."""
    query: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="Search query text"
    )
    top_k: int = Field(
        default=5,
        ge=1,
        le=50,
        description="Number of results to return"
    )
    include_metadata: bool = Field(
        default=True,
        description="Include metadata in results"
    )


class SearchStrategy(str, Enum):
    """Search strategy options."""
    VECTOR = "vector"
    GRAPH = "graph"
    HYBRID = "hybrid"


FILTER_KEY_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")
MAX_FILTER_FIELDS = 20
MAX_FILTER_VALUES_PER_FIELD = 20
MAX_FILTER_STRING_LENGTH = 200


class AdvancedQueryRequest(BaseModel):
    """Advanced query with additional options."""
    query: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="Search query text"
    )
    top_k: int = Field(
        default=5,
        ge=1,
        le=50,
        description="Number of results to return"
    )
    strategy: SearchStrategy = Field(
        default=SearchStrategy.HYBRID,
        description="Search strategy to use"
    )
    vector_weight: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Weight for vector search results"
    )
    graph_weight: float = Field(
        default=0.3,
        ge=0.0,
        le=1.0,
        description="Weight for graph search results"
    )
    use_reranking: bool = Field(
        default=True,
        description="Apply reranking to results"
    )
    use_query_expansion: bool = Field(
        default=False,
        description="Expand query with synonyms/related terms"
    )
    filters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata filters for search"
    )
    include_graph_context: bool = Field(
        default=True,
        description="Include knowledge graph context in results"
    )
    graph_policy: Optional[str] = Field(
        default=None,
        description="Optional graph retrieval policy override (standard, local, global, drift, community)"
    )

    @field_validator('graph_weight')
    @classmethod
    def validate_weights(cls, v: float, info) -> float:
        """Validate that weights sum to approximately 1.0."""
        vector_weight = info.data.get('vector_weight', 0.7)
        total = vector_weight + v
        if not (0.95 <= total <= 1.05):
            raise ValueError("vector_weight + graph_weight must sum to approximately 1.0")
        return v

    @field_validator("graph_policy")
    @classmethod
    def validate_graph_policy(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        normalized = v.strip().lower()
        if normalized not in {"standard", "local", "global", "drift", "community", "adaptive"}:
            raise ValueError(
                "graph_policy must be one of: standard, local, global, drift, community, adaptive"
            )
        return normalized

    @field_validator("filters")
    @classmethod
    def validate_filters(cls, value: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if value is None:
            return None
        if len(value) > MAX_FILTER_FIELDS:
            raise ValueError(f"filters supports at most {MAX_FILTER_FIELDS} fields")

        normalized: Dict[str, Any] = {}
        for raw_key, raw_value in value.items():
            key = str(raw_key).strip()
            if not FILTER_KEY_PATTERN.fullmatch(key):
                raise ValueError(
                    "filter keys must match ^[A-Za-z_][A-Za-z0-9_]{0,63}$"
                )
            normalized[key] = cls._normalize_filter_value(raw_value)
        return normalized

    @classmethod
    def _normalize_filter_value(cls, value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, str):
            token = value.strip()
            if not token:
                raise ValueError("filter string values cannot be empty")
            if len(token) > MAX_FILTER_STRING_LENGTH:
                raise ValueError(
                    f"filter string values must be <= {MAX_FILTER_STRING_LENGTH} characters"
                )
            return token
        if isinstance(value, (list, tuple, set)):
            items = [cls._normalize_filter_scalar(item) for item in value]
            if not items:
                raise ValueError("filter list values cannot be empty")
            if len(items) > MAX_FILTER_VALUES_PER_FIELD:
                raise ValueError(
                    f"filter list values support at most {MAX_FILTER_VALUES_PER_FIELD} entries"
                )
            return items
        raise ValueError(
            "filter values must be string, number, boolean, null, or a list of those values"
        )

    @staticmethod
    def _normalize_filter_scalar(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, str):
            token = value.strip()
            if not token:
                raise ValueError("filter list string values cannot be empty")
            if len(token) > MAX_FILTER_STRING_LENGTH:
                raise ValueError(
                    f"filter list string values must be <= {MAX_FILTER_STRING_LENGTH} characters"
                )
            return token
        raise ValueError("filter list values must be string, number, boolean, or null")


class StreamQueryRequest(BaseModel):
    """Request for streaming query results."""
    query: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="Search query text"
    )
    top_k: int = Field(
        default=10,
        ge=1,
        le=100,
        description="Number of results to stream"
    )
    strategy: SearchStrategy = Field(
        default=SearchStrategy.HYBRID,
        description="Search strategy to use"
    )


class DocumentFilterRequest(BaseModel):
    """Request for filtering document list."""
    file_type: Optional[str] = Field(
        default=None,
        description="Filter by file type (pdf, docx, txt, etc.)"
    )
    min_chunks: Optional[int] = Field(
        default=None,
        ge=0,
        description="Minimum number of chunks"
    )
    max_chunks: Optional[int] = Field(
        default=None,
        ge=0,
        description="Maximum number of chunks"
    )
    has_entities: Optional[bool] = Field(
        default=None,
        description="Filter by entity extraction status"
    )
    search: Optional[str] = Field(
        default=None,
        max_length=200,
        description="Search in document names"
    )


class AgenticQueryRequest(BaseModel):
    """Request for agentic RAG query."""
    query: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Complex query for agentic processing"
    )
    max_iterations: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum iterations for agentic refinement"
    )
    use_evaluation: bool = Field(
        default=True,
        description="Use evaluation agent to assess quality"
    )
    return_reasoning: bool = Field(
        default=True,
        description="Include reasoning steps in response"
    )


class RetrievalFeedbackLabel(BaseModel):
    """Explicit label for one retrieval result."""

    result_id: str = Field(
        ...,
        min_length=1,
        max_length=300,
        description="Identifier of a returned retrieval result"
    )
    label: int = Field(
        ...,
        ge=0,
        le=1,
        description="Relevance label where 1 is relevant and 0 is not relevant"
    )
    note: Optional[str] = Field(
        default=None,
        max_length=500,
        description="Optional reviewer note for the labeled result"
    )


class RetrievalFeedbackRequest(BaseModel):
    """Request body for retrieval feedback capture."""

    query_id: str = Field(
        ...,
        min_length=1,
        max_length=128,
        description="Query identifier returned by search metadata"
    )
    helpful: Optional[bool] = Field(
        default=None,
        description="Overall helpfulness signal for the returned evidence set"
    )
    selected_result_ids: List[str] = Field(
        default_factory=list,
        description="Result identifiers marked as useful evidence"
    )
    result_labels: List[RetrievalFeedbackLabel] = Field(
        default_factory=list,
        description="Optional explicit positive or negative labels per result"
    )
    comment: Optional[str] = Field(
        default=None,
        max_length=1000,
        description="Optional feedback comment"
    )
    user_id: Optional[str] = Field(
        default=None,
        max_length=120,
        description="Optional user identifier for attribution"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Optional metadata for auditing and analysis"
    )

    @field_validator("selected_result_ids")
    @classmethod
    def validate_selected_result_ids(cls, values: List[str]) -> List[str]:
        deduped: List[str] = []
        seen = set()
        for value in values:
            token = str(value).strip()
            if not token or token in seen:
                continue
            seen.add(token)
            deduped.append(token)
        return deduped


class Neo4jPasswordRecoveryRequest(BaseModel):
    """Request body for Neo4j password verification and optional save."""

    password: str = Field(
        ...,
        min_length=1,
        max_length=256,
        description="Neo4j password to verify",
    )
    persist_to_env: bool = Field(
        default=True,
        description="When true, write NEO4J_PASSWORD to local .env file",
    )
