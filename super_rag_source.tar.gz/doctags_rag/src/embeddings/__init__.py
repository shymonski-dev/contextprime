"""Embedding utilities."""

from .openai_embedder import OpenAIEmbeddingModel

__all__ = ["OpenAIEmbeddingModel"]
